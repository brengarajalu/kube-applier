package run

import (
	"github.com/box/kube-applier/gitutil"
	"github.com/box/kube-applier/util"
	"time"
)

type CheckerInterface interface {
	ShouldRun(lastRun *Result) (bool, error)
}

type Checker struct {
	RepoInfoFetcher gitutil.RepoInfoFetcherInterface
	Clock           util.ClockInterface
	FullRunInterval time.Duration
}

// ShouldRun checks if an apply run is necessary. There are two indicators that a run is necessary.
// 1. The HEAD commit hash of the repo has changed since the last run.
// 2. The time passed since the last run is greater than the specified interval for periodic runs.
func (c Checker) ShouldRun(lastRun *Result) (bool, error) {
	newCommitHash, err := c.RepoInfoFetcher.GetHeadHash()
	if err != nil {
		return false, err
	}
	if newCommitHash != lastRun.CommitHash {
		return true, nil
	}
	return (c.Clock.Since(lastRun.Finish) > c.FullRunInterval), nil
}
