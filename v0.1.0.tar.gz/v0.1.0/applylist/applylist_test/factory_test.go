package applylist_test

import (
	"fmt"
	"github.com/box/kube-applier/applylist"
	"github.com/box/kube-applier/filesystem"
	"github.com/box/kube-applier/filesystem/mock_filesystem"
	"github.com/golang/mock/gomock"
	"github.com/stretchr/testify/assert"
	"testing"
)

type testCase struct {
	repoPath          string
	blacklistPath     string
	fsh               filesystem.HelperInterface
	expectedApplyList []string
	expectedBlacklist []string
	expectedErr       error
}

func TestFactory_Create(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	fsh := mock_filesystem.NewMockHelperInterface(mockCtrl)

	// ReadLines error -> return nil lists and error, ListAllFiles not called
	gomock.InOrder(
		fsh.EXPECT().ReadLines("/blacklist").Times(1).Return(nil, fmt.Errorf("error")),
	)
	tc := testCase{"/repo", "/blacklist", fsh, nil, nil, fmt.Errorf("error")}
	createAndAssert(t, tc)

	// ListAllFiles error -> return nil lists and error, ReadLines is called
	gomock.InOrder(
		fsh.EXPECT().ReadLines("/blacklist").Times(1).Return([]string{}, nil),
		fsh.EXPECT().ListAllFiles("/repo").Times(1).Return(nil, fmt.Errorf("error")),
	)
	tc = testCase{"/repo", "/blacklist", fsh, nil, nil, fmt.Errorf("error")}
	createAndAssert(t, tc)

	// All lists and paths empty -> both lists empty
	gomock.InOrder(
		fsh.EXPECT().ReadLines("").Times(1).Return([]string{}, nil),
		fsh.EXPECT().ListAllFiles("").Times(1).Return([]string{}, nil),
	)
	tc = testCase{"", "", fsh, []string{}, []string{}, nil}
	createAndAssert(t, tc)

	// Single .json file, empty blacklist -> file in applyList
	gomock.InOrder(
		fsh.EXPECT().ReadLines("/blacklist").Times(1).Return([]string{}, nil),
		fsh.EXPECT().ListAllFiles("/repo").Times(1).Return([]string{"/repo/a.json"}, nil),
	)
	tc = testCase{"/repo", "/blacklist", fsh, []string{"/repo/a.json"}, []string{}, nil}
	createAndAssert(t, tc)

	// Single .yaml file, empty blacklist -> file in applyList
	gomock.InOrder(
		fsh.EXPECT().ReadLines("/blacklist").Times(1).Return([]string{}, nil),
		fsh.EXPECT().ListAllFiles("/repo").Times(1).Return([]string{"/repo/a.yaml"}, nil),
	)
	tc = testCase{"/repo", "/blacklist", fsh, []string{"/repo/a.yaml"}, []string{}, nil}
	createAndAssert(t, tc)

	// Single non-.json & non-.yaml file, empty blacklist -> file not in applyList
	gomock.InOrder(
		fsh.EXPECT().ReadLines("/blacklist").Times(1).Return([]string{}, nil),
		fsh.EXPECT().ListAllFiles("/repo").Times(1).Return([]string{"/repo/a"}, nil),
	)
	tc = testCase{"/repo", "/blacklist", fsh, []string{}, []string{}, nil}
	createAndAssert(t, tc)

	// Multiple files (mixed extensions), empty blacklist
	gomock.InOrder(
		fsh.EXPECT().ReadLines("/blacklist").Times(1).Return([]string{}, nil),
		fsh.EXPECT().ListAllFiles("/repo").Times(1).Return([]string{"/repo/a.json", "/repo/b.jpg", "/repo/a/b.yaml", "/repo/a/b"}, nil),
	)
	tc = testCase{"/repo", "/blacklist", fsh, []string{"/repo/a.json", "/repo/a/b.yaml"}, []string{}, nil}
	createAndAssert(t, tc)

	// Multiple files (mixed extensions), blacklist
	gomock.InOrder(
		fsh.EXPECT().ReadLines("/blacklist").Times(1).Return([]string{"b.json", "b/c.json"}, nil),
		fsh.EXPECT().ListAllFiles("/repo").Times(1).Return([]string{"/repo/a.json", "/repo/b.json", "/repo/a/b/c.yaml", "/repo/a/b", "/repo/b/c.json"}, nil),
	)
	tc = testCase{"/repo", "/blacklist", fsh, []string{"/repo/a.json", "/repo/a/b/c.yaml"}, []string{"/repo/b.json", "/repo/b/c.json"}, nil}
	createAndAssert(t, tc)

	// Multiple files (mixed extensions), blacklist
	gomock.InOrder(
		fsh.EXPECT().ReadLines("/blacklist").Times(1).Return([]string{"b.json", "b/c.json"}, nil),
		fsh.EXPECT().ListAllFiles("/repo").Times(1).Return([]string{"/repo/a.json", "/repo/b.json", "/repo/a/b/c.yaml", "/repo/a/b", "/repo/b/c.json"}, nil),
	)
	tc = testCase{"/repo", "/blacklist", fsh, []string{"/repo/a.json", "/repo/a/b/c.yaml"}, []string{"/repo/b.json", "/repo/b/c.json"}, nil}
	createAndAssert(t, tc)

	// File in blacklist but not in repo
	// (Ends up on returned blacklist anyway)
	gomock.InOrder(
		fsh.EXPECT().ReadLines("/blacklist").Times(1).Return([]string{"a/b/c.yaml", "f.json"}, nil),
		fsh.EXPECT().ListAllFiles("/repo").Times(1).Return([]string{"/repo/a/b.json", "/repo/b/c", "/repo/a/b/c.yaml", "/repo/a/b/c", "/repo/c.json"}, nil),
	)
	tc = testCase{"/repo", "/blacklist", fsh, []string{"/repo/a/b.json", "/repo/c.json"}, []string{"/repo/a/b/c.yaml", "/repo/f.json"}, nil}
	createAndAssert(t, tc)
}

func createAndAssert(t *testing.T, tc testCase) {
	assert := assert.New(t)
	f := applylist.Factory{tc.repoPath, tc.blacklistPath, tc.fsh}
	applyList, blacklist, err := f.Create()
	assert.Equal(tc.expectedApplyList, applyList)
	assert.Equal(tc.expectedBlacklist, blacklist)
	assert.Equal(tc.expectedErr, err)
}
