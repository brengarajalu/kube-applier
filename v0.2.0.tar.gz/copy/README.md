# kube-applier

[![Project Status](http://opensource.box.com/badges/active.svg)](http://opensource.box.com/badges)

kube-applier is a service that enables continuous deployment of Kubernetes objects by checking declarative configuration files into a Git repository. 

It watches the [Git repo](#mounting-the-git-repository) and ensures that Kubernetes objects are up-to-date with their associated spec files (JSON or YAML) in the repo.

Whenever a new commit to the repo occurs, or after a [certain length of time since the last commit](#run-interval), kube-applier performs a full run, applying all JSON and YAML files within the repo.

kube-applier serves a [status page](#status-ui) and provides [metrics](#metrics) for monitoring.

## Setup
Clone the repository and build the container.
```
$ git clone https://github.com/box/kube-applier
$ cd kube-applier
$ make container
```

Test the container.
```
$ docker run -e "REPO_PATH=<path>" -e "LISTEN_PORT=<port>" kube-applier:v0.1.0 /kube-applier
```

## Usage

### Container Spec
Within a Pod or Deployment spec, create a spec for a kube-applier container. See [demo/](demo) for example YAML files.

### Environment Variables

**Required:**
* ``REPO_PATH`` - Path to the root directory for the configuration files to be applied. It must be a Git repository or located within one. All .json and .yaml files within this directory (and its subdirectories) will be applied, unless listed on the blacklist
* ``LISTEN_PORT`` - Port for the container. This should be the same port specified in the container spec

**Optional:**
* ``SERVER`` - Address of the Kubernetes API server (see [Kubernetes API Server Authentication](#kubernetes-api-server-authentication) below).
* ``BLACKLIST_PATH`` - Path to a blacklist file which specifies files that should not be applied. The blacklist file itself should be a plaintext file, with a file path on each line. Each path should be relative to the repo directory (for example, if the repo is located at /git/repo and the file is /git/repo/apps/app1.json, the path in the blacklist file should be "apps/app1.json").
* ``POLL_INTERVAL_SECONDS`` - Number of seconds to wait between each check for new commits to the repo (default is 5).
* <a name="run-interval"></a>``FULL_RUN_INTERVAL_SECONDS`` - Number of seconds to wait between apply runs if no new commits have been added to the repo (default is 300, or 5 minutes)
* ``DIFF_URL_FORMAT`` - If specified, allows the status page to display a link to the source code referencing the diff for a specific commit. ``DIFF_URL_FORMAT`` should be a URL for a hosted remote repo that supports linking to a commit hash. Replace the commit hash portion with "%s" so it can be filled in by kube-applier. As an example: ``https://github.com/kubernetes/kubernetes/commit/%s``

### Mounting the Git Repository

There are two ways to mount the Git repository into the kube-applier container.

**1. Git-sync sidecar container**

Git-sync keeps a local directory up to date with a remote repo. The local directory resides in a shared emptyDir volume that is mounted in both the git-sync and kube-applier containers.

Reference the [git-sync](https://https://github.com/kubernetes/git-sync) repo for setup and usage.

**2. Host-mounted volume**

Mount a Git repository from a host directory. This can be useful when you want kube-applier to apply changes to an object without checking the modified spec file into a remote repo.
```
"volumes": [
   {
      "hostPath": {
         "path": <path-to-host-directory>
      },
      "name": "repo-volume"
   }
   ...
]
```

### Kubernetes API Server Authentication
By default, discovery of the API server is handled by kube-proxy. If kube-proxy is not set up, the API server address must be specified in the ``$SERVER`` environment variable (which is then written into a [kubeconfig file](http://kubernetes.io/docs/user-guide/kubeconfig-file/) on the backend).

Authentication to the API server is handled by service account tokens. See [Accessing the Cluster](http://kubernetes.io/docs/user-guide/accessing-the-cluster/#accessing-the-api-from-a-pod) for more info.

***IMPORTANT:*** The Pod containing the kube-applier container must be spawned in a namespace that has write permissions on all namespaces in the API Server (e.g. kube-system).

## Monitoring
### Status UI
kube-applier hosts a status page on a webserver, served at the service endpoint URL. The status page displays information about the most recent apply run, including:
* Start and end times
* Latency
* Most recent commit
* Blacklisted files
* Errors
* Files applied successfully

The HTML template for the status page lives in ``templates/status.html``, and ``static/`` holds additional assets. The data is provided to the template as a ``Result`` struct from the ``run`` package (see ``run/`` and ``webserver/``).

### Metrics
kube-applier uses [Prometheus](https://github.com/prometheus/client_golang) for metrics. Metrics are hosted/served at on the webserver at /metrics. In addition to the Prometheus default metrics, the following custom metrics are included:
* **run_latency** - A [Summary](https://godoc.org/github.com/prometheus/client_golang/prometheus#Summary) that keeps track of the durations of each apply run.
* **file_apply_count** - A [Counter](https://godoc.org/github.com/prometheus/client_golang/prometheus#Counter) for each file that has had an apply attempt over the lifetime of the container, incremented with each apply attempt and tagged by the filepath and the result of the attempt.

The Prometheus [HTTP API](https://prometheus.io/docs/querying/api/) (also see the [Go library](https://github.com/prometheus/client_golang/tree/master/api/prometheus)) can be used for querying the metrics server.

##Testing
See our [contributing guidelines](CONTRIBUTING.md#step-7-run-the-tests).

## Support

Need to contact us directly? Email oss@box.com and be sure to include the name of this project in the subject.

## Copyright and License

Copyright 2016 Box, Inc. All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
