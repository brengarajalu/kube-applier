package filesystem

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
)

type HelperInterface interface {
	ReadLines(filePath string) ([]string, error)
	ListAllFiles(rootPath string) ([]string, error)
}

type Helper struct{}

// ReadLines opens the file located at the path and reads each line into a []string.
func (h Helper) ReadLines(filePath string) ([]string, error) {
	f, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("Error opening the file at %v: %v", filePath, err)
	}
	defer f.Close()

	result := []string{}
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		result = append(result, scanner.Text())
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("Error reading the file at %v: %v", filePath, err)
	}
	return result, nil
}

// ListAllFiles walks the directory tree rooted at the path and adds all non-directory file paths to a []string.
func (h Helper) ListAllFiles(rootPath string) ([]string, error) {
	result := []string{}

	err := filepath.Walk(rootPath,
		func(path string, f os.FileInfo, e error) error {
			if e != nil {
				return e
			}
			if !f.IsDir() {
				result = append(result, path)
			}
			return nil
		})
	if err != nil {
		return nil, fmt.Errorf("Error walking the directory tree rooted at %v: %v", rootPath, err)
	}
	return result, nil
}
