package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"net/http"
	"strconv"
)

type PrometheusInterface interface {
	UpdateFileSuccess(string, bool)
	UpdateRunLatency(float64)
}

type Prometheus struct {
	fileApplyCount *prometheus.CounterVec
	runLatency     prometheus.Summary
}

func (p *Prometheus) GetHandler() http.Handler {
	return prometheus.UninstrumentedHandler()
}

func (p *Prometheus) Init() {
	p.fileApplyCount = prometheus.NewCounterVec(prometheus.CounterOpts{
		Name: "file_apply_count",
		Help: "Success metric for every file applied",
	},
		[]string{
			// Path of the file that was applied
			"file",
			// Result: true if the apply was successful, false otherwise
			"success",
		},
	)
	p.runLatency = prometheus.NewSummary(prometheus.SummaryOpts{
		Name: "run_latency",
		Help: "Latency for the last complete apply run",
	})

	prometheus.MustRegister(p.fileApplyCount)
	prometheus.MustRegister(p.runLatency)
}

func (p *Prometheus) UpdateFileSuccess(file string, success bool) {
	p.fileApplyCount.With(prometheus.Labels{
		"file": file, "success": strconv.FormatBool(success),
	}).Inc()
}

func (p *Prometheus) UpdateRunLatency(runLatency float64) {
	p.runLatency.Observe(runLatency)
}
