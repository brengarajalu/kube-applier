package gitutil

import (
	"fmt"
	"os/exec"
	"strings"
)

type RepoInfoFetcherInterface interface {
	GetHeadHash() (string, error)
	GetHeadCommitLog() (string, error)
}

type RepoInfoFetcher struct {
	RepoPath string
}

func (f RepoInfoFetcher) GetHeadHash() (string, error) {
	hash, err := runGitCmd(f.RepoPath, "rev-parse", "HEAD")
	return strings.TrimSuffix(hash, "\n"), err
}

func (f RepoInfoFetcher) GetHeadCommitLog() (string, error) {
	log, err := runGitCmd(f.RepoPath, "log", "-1", "--name-status")
	return log, err
}

func runGitCmd(dir string, args ...string) (string, error) {
	var cmd *exec.Cmd
	cmd = exec.Command("git", args...)
	cmd.Dir = dir
	output, err := cmd.CombinedOutput()
	if err != nil {
		return "", fmt.Errorf("Error running command %v: %v: %s", strings.Join(cmd.Args, " "), err, output)
	}
	return string(output), nil
}
