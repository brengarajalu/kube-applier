# Demo

An example Deployment and Service spec for kube-applier, with git-sync as a sidecar container.