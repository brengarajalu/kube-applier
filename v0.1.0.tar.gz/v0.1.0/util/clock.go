package util

import "time"

type ClockInterface interface {
	Now() time.Time
	Since(time.Time) time.Duration
	Sleep(time.Duration)
}

type Clock struct{}

func (c *Clock) Now() time.Time {
	return time.Now()
}

func (c *Clock) Since(t time.Time) time.Duration {
	return time.Since(t)
}

func (c *Clock) Sleep(d time.Duration) {
	time.Sleep(d)
}
