package webserver

import (
	"fmt"
	"github.com/box/kube-applier/util"
	"html/template"
	"log"
	"net/http"
)

const serverTemplatePath = "/templates/status.html"

type StatusPageHandler struct {
	template *template.Template
	data     interface{}
	clock    util.ClockInterface
}

func (s StatusPageHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	log.Printf("Applier status request at %s", s.clock.Now().String())
	if s.template == nil {
		handleTemplateError(w, fmt.Errorf("No template found"), s.clock)
		return
	}
	if err := s.template.Execute(w, s.data); err != nil {
		handleTemplateError(w, err, s.clock)
		return
	}
	log.Printf("Request completed successfully at %s", s.clock.Now().String())
}

func handleTemplateError(w http.ResponseWriter, err error, clock util.ClockInterface) {
	log.Printf("Error applying template: %v", err)
	http.Error(w, "Error: Unable to load HTML template", http.StatusInternalServerError)
	log.Printf("Request failed with error code %v at %s", http.StatusInternalServerError, clock.Now().String())
}

func StartWebServer(listenPort int, data interface{}, clock util.ClockInterface, metricsHandler http.Handler) error {
	log.Println("Launching webserver")

	template, err := util.CreateTemplate(serverTemplatePath)
	if err != nil {
		return err
	}

	handler := StatusPageHandler{template, data, clock}
	http.Handle("/", handler)
	http.Handle("/metrics", metricsHandler)
	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))
	err = http.ListenAndServe(fmt.Sprintf(":%v", listenPort), nil)
	return err
}
