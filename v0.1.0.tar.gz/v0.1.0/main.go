package main

import (
	"github.com/box/kube-applier/applylist"
	"github.com/box/kube-applier/filesystem"
	"github.com/box/kube-applier/gitutil"
	"github.com/box/kube-applier/kube"
	"github.com/box/kube-applier/metrics"
	"github.com/box/kube-applier/run"
	"github.com/box/kube-applier/util"
	"github.com/box/kube-applier/webserver"
	"log"
	"strings"
	"time"
)

const (
	defaultPollIntervalSeconds    = 5
	defaultFullRunIntervalSeconds = 5 * 60
	waitForRepoInterval           = 1 * time.Second
)

func startApplierLoop(lastRun *run.Result, runChecker run.CheckerInterface, runner run.RunnerInterface, clock util.ClockInterface, pollInterval time.Duration) {
	for {
		shouldRun, err := runChecker.ShouldRun(lastRun)
		if err != nil {
			log.Fatal(err)
		}
		if shouldRun {
			newRun, err := runner.Run()
			if err != nil {
				log.Fatal(err)
			}
			*lastRun = *newRun
		}
		clock.Sleep(pollInterval)
	}
}

func main() {
	repoPath := util.GetRequiredEnvString("REPO_PATH")
	listenPort := util.GetRequiredEnvInt("LISTEN_PORT")
	server := util.GetEnvStringOrDefault("SERVER", "")
	blacklistPath := util.GetEnvStringOrDefault("BLACKLIST_PATH", "")
	diffURLFormat := util.GetEnvStringOrDefault("DIFF_URL_FORMAT", "")
	pollInterval := time.Duration(util.GetEnvIntOrDefault("POLL_INTERVAL_SECONDS", defaultPollIntervalSeconds)) * time.Second
	fullRunInterval := time.Duration(util.GetEnvIntOrDefault("FULL_RUN_INTERVAL_SECONDS", defaultFullRunIntervalSeconds)) * time.Second
	lastRun := &run.Result{}

	if diffURLFormat != "" && !strings.Contains(diffURLFormat, "%s") {
		log.Fatalf("Invalid DIFF_URL_FORMAT, must contain %q: %v", "%s", diffURLFormat)
	}

	metrics := &metrics.Prometheus{}
	metrics.Init()

	clock := &util.Clock{}

	if err := util.WaitForDir(repoPath, clock, waitForRepoInterval); err != nil {
		log.Fatal(err)
	}

	kubeClient := kube.Client{server}
	kubeClient.Configure()

	batchApplier := run.BatchApplier{kubeClient, metrics}
	repoInfoFetcher := gitutil.RepoInfoFetcher{repoPath}
	fileSystemHelper := filesystem.Helper{}
	listFactory := applylist.Factory{repoPath, blacklistPath, fileSystemHelper}
	runChecker := run.Checker{repoInfoFetcher, clock, fullRunInterval}

	runner := run.Runner{
		batchApplier,
		listFactory,
		repoInfoFetcher,
		clock,
		metrics,
		diffURLFormat,
	}

	go startApplierLoop(lastRun, runChecker, runner, clock, pollInterval)

	// If it returns, startWebServer returns a non-nil error from http.ListenAndServe
	err := webserver.StartWebServer(listenPort, lastRun, clock, metrics.GetHandler())
	log.Fatalf("Webserver error: %v", err)
}
