package run

import (
	"github.com/box/kube-applier/applylist"
	"github.com/box/kube-applier/gitutil"
	"github.com/box/kube-applier/metrics"
	"github.com/box/kube-applier/util"
	"log"
)

type RunnerInterface interface {
	Run() (*Result, error)
}

type Runner struct {
	BatchApplier    BatchApplierInterface
	ListFactory     applylist.FactoryInterface
	RepoInfoFetcher gitutil.RepoInfoFetcherInterface
	Clock           util.ClockInterface
	Metrics         metrics.PrometheusInterface
	DiffURLFormat   string
}

// Run performs a full apply run, and returns a Result with data about the completed run (or nil if the run failed to complete).
func (r Runner) Run() (*Result, error) {

	applyRunStart := r.Clock.Now()
	log.Printf("Started apply run at %v", applyRunStart)

	applyList, blacklist, err := r.ListFactory.Create()
	if err != nil {
		return nil, err
	}

	commitHash, err := r.RepoInfoFetcher.GetHeadHash()
	if err != nil {
		return nil, err
	}
	fullCommitLog, err := r.RepoInfoFetcher.GetHeadCommitLog()
	if err != nil {
		return nil, err
	}

	successes, failures := r.BatchApplier.Apply(applyList)

	applyRunFinish := r.Clock.Now()

	log.Printf("Finished apply run at %v", applyRunFinish)

	r.Metrics.UpdateRunLatency(r.Clock.Since(applyRunStart).Seconds())

	newRun := Result{applyRunStart, applyRunFinish, commitHash, fullCommitLog, blacklist, successes, failures, r.DiffURLFormat}
	return &newRun, nil
}
