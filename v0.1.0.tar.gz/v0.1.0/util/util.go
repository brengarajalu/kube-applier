package util

import (
	"fmt"
	"html/template"
	"log"
	"os"
	"path"
	"strconv"
	"time"
)

// PrependToEachPath prepends the specified prefix path to the base path, using path.Join to handle slashes.
func PrependToEachPath(prefix string, paths []string) []string {
	result := []string{}
	for _, basePath := range paths {
		result = append(result, path.Join(prefix, basePath))
	}
	return result
}

// StringSliceToMap creates a map with the slice's strings as keys and empty structs as values.
// The map is intended to be used for easy lookup across the set of strings.
func StringSliceToMap(strings []string) map[string]struct{} {
	m := make(map[string]struct{})
	for _, s := range strings {
		m[s] = struct{}{}
	}
	return m
}

func CreateTemplate(templatePath string) (*template.Template, error) {
	if _, err := os.Stat(templatePath); err != nil {
		return nil, fmt.Errorf("Error opening template file: %v", err)
	}
	template, err := template.ParseFiles(templatePath)
	if err != nil {
		return nil, fmt.Errorf("Error parsing template: %v", err)
	}
	return template, nil
}

func GetRequiredEnvString(key string) string {
	val := os.Getenv(key)
	if len(val) == 0 {
		log.Fatalf("Error: Missing environment variable %v", key)
	}
	return val
}

func GetRequiredEnvInt(key string) int {
	stringVal := GetRequiredEnvString(key)
	intVal, err := strconv.Atoi(stringVal)
	if err != nil {
		log.Fatalf("Error converting environment variable %s to int: %v", stringVal, err)
	}
	return intVal
}

// Source: https://github.com/kubernetes/contrib/git-sync/main.go
func GetEnvIntOrDefault(key string, def int) int {
	if env := os.Getenv(key); env != "" {
		val, err := strconv.Atoi(env)
		if err != nil {
			log.Printf("Invalid value for %v: using default: %v", key, def)
			return def
		}
		return val
	}
	return def
}

// Source: https://github.com/kubernetes/contrib/git-sync/main.go
func GetEnvStringOrDefault(key, def string) string {
	if env := os.Getenv(key); env != "" {
		return env
	}
	return def
}

func WaitForDir(path string, clock ClockInterface, interval time.Duration) error {
	log.Printf("Waiting for directory at %v...", path)
	for {
		f, err := os.Stat(path)
		if err != nil {
			if !os.IsNotExist(err) {
				return fmt.Errorf("Error opening the directory at %v: %v", path, err)
			}
		} else if !f.IsDir() {
			return fmt.Errorf("Error: %v is not a directory", path)
		} else {
			log.Printf("Found directory at %v", path)
			break
		}
		clock.Sleep(interval)
	}
	return nil
}
