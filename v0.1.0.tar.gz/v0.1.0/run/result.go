package run

import (
	"fmt"
	"strings"
	"time"
)

// Result stores the data from a single run of the apply loop.
type Result struct {
	Start         time.Time
	Finish        time.Time
	CommitHash    string
	FullCommit    string
	Blacklist     []string
	Successes     []ApplyAttempt
	Failures      []ApplyAttempt
	DiffURLFormat string
}

func (r Result) FormattedStart() string {
	return r.Start.Truncate(time.Second).String()
}

func (r Result) FormattedFinish() string {
	return r.Finish.Truncate(time.Second).String()
}

func (r Result) Latency() string {
	return fmt.Sprintf("%.3f sec", r.Finish.Sub(r.Start).Seconds())
}

func (r Result) TotalFiles() int {
	return len(r.Successes) + len(r.Failures)
}

func (r Result) LastCommitLink() string {
	if r.CommitHash == "" || r.DiffURLFormat == "" || !strings.Contains(r.DiffURLFormat, "%s") {
		return ""
	}
	return fmt.Sprintf(r.DiffURLFormat, r.CommitHash)
}
